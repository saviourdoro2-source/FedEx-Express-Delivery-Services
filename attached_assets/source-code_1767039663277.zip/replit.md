# FedExpress Shipping

## Overview

FedExpress Shipping is a full-stack web application for managing and tracking shipping operations. The application provides a professional logistics platform inspired by FedEx/DHL, featuring user authentication, shipment creation, real-time tracking, and comprehensive shipment history management. Built with a modern tech stack, it offers a clean, corporate aesthetic emphasizing trust, speed, and reliability.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build Tools**
- React 18+ with TypeScript for type-safe component development
- Vite as the build tool and development server, providing fast HMR (Hot Module Replacement)
- Wouter for lightweight client-side routing (alternative to React Router)
- TanStack Query (React Query) for server state management, caching, and data synchronization

**UI Component System**
- shadcn/ui component library built on Radix UI primitives for accessible, unstyled components
- Tailwind CSS for utility-first styling with custom design tokens
- Custom CSS variables system for theming (supports light/dark modes)
- Class Variance Authority (CVA) for component variant management

**Design System**
- Professional FedEx/DHL-inspired corporate aesthetic
- Primary purple (#4B2E83) and accent orange (#FF7A00) color scheme
- Montserrat font family (300-900 weights) via Google Fonts
- Consistent spacing system with 16-28px card padding and 10-12px border radius
- Elevated shadow system for depth and hierarchy

**State Management**
- Context API for global state (Auth, Theme)
- TanStack Query for server state
- Local component state with React hooks
- LocalStorage for auth token and user persistence

### Backend Architecture

**Server Framework**
- Express.js as the HTTP server framework
- Node.js runtime with ES modules
- Custom logging middleware for request tracking
- Static file serving for production builds

**Authentication & Security**
- JWT (JSON Web Tokens) for stateless authentication
- bcrypt for password hashing with salt rounds
- Bearer token authentication via Authorization headers
- Middleware-based route protection for authenticated endpoints

**API Design**
- RESTful API structure with `/api` prefix
- JSON request/response format
- Standardized error handling with appropriate HTTP status codes
- Route organization pattern separating auth, shipment, and tracking endpoints

**Database Layer**
- Drizzle ORM for type-safe database operations
- PostgreSQL as the primary database (via connection pooling with node-postgres)
- Schema-first approach with TypeScript types generated from Drizzle schemas
- Migration support via Drizzle Kit

### Data Storage Solutions

**Database Schema**
- **users table**: Stores user accounts with id, name, email, password hash, and timestamps
- **shipments table**: Core shipment data including tracking IDs, sender/recipient info, origin/destination, weight, status, and creator reference
- **shipment_events table**: Event log for tracking shipment status changes with location, notes, and timestamps

**Relationships**
- One-to-many: User → Shipments (user can create multiple shipments)
- One-to-many: Shipment → Shipment Events (each shipment has multiple status events)
- Foreign key constraints ensure referential integrity

**Data Access Pattern**
- Storage abstraction layer (`IStorage` interface) for database operations
- Dedicated storage class (`DatabaseStorage`) implementing CRUD operations
- Separation of concerns between route handlers and data access logic

### External Dependencies

**Core Runtime & Build**
- Node.js with TypeScript compilation
- esbuild for server-side bundling (production builds)
- Vite for client-side bundling and development server
- tsx for TypeScript execution in development

**UI & Styling**
- @radix-ui/* packages (20+ components): Accessible UI primitives for dialogs, dropdowns, forms, etc.
- Tailwind CSS with PostCSS for processing
- Google Fonts (Montserrat) for typography
- Lucide React for icon components

**Authentication & Security**
- jsonwebtoken: JWT generation and verification
- bcrypt: Password hashing
- Session management libraries (connect-pg-simple for potential future use)

**Database**
- drizzle-orm: TypeScript ORM
- drizzle-kit: Schema migrations and management
- pg (node-postgres): PostgreSQL client with connection pooling

**State & Data Fetching**
- @tanstack/react-query: Server state management
- React Hook Form with @hookform/resolvers and Zod for form validation

**Development Tools**
- @replit/vite-plugin-* packages: Replit-specific tooling for development experience
- TypeScript for static type checking across the stack

**Environment Configuration**
- DATABASE_URL: PostgreSQL connection string (required)
- SESSION_SECRET: JWT signing secret (defaults to demo key if not provided)
- NODE_ENV: Environment mode (development/production)
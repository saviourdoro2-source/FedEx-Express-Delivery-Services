# Design Guidelines: FedExpress Shipping

## Design Approach
**Reference-Based**: Inspired by FedEx/DHL logistics platforms with clean, professional, corporate aesthetic emphasizing trust, speed, and reliability.

## Brand Identity

### Color Palette
- **Primary Purple**: `#4B2E83` (deep purple for headers, primary buttons, trust elements)
- **Accent Orange**: `#FF7A00` (vibrant orange for CTAs, highlights, secondary actions)
- **Background Gradient**: White to `#f6f6f8` (subtle muted gray)
- **Text**: `#222` primary, `#666` for muted/secondary text

### Typography
- **Font Family**: Montserrat (Google Fonts)
- **Weights**: 300 (light), 400 (regular), 600 (semibold), 700 (bold), 900 (black)
- **Headings**: 800-900 weight for strong hierarchy
- **Body**: 400 weight, high readability

## Layout System

### Spacing
- **Container**: Max-width 1100px, centered with 28px top margin, 18px padding
- **Card Padding**: 16-28px depending on prominence
- **Section Gaps**: 16-24px between elements
- **Grid Gaps**: 16px standard

### Grid Patterns
- **3-column grid** for feature cards (responsive to 1-column mobile)
- **2-column hero** layout with content left, tracking widget right
- **Form layouts**: Vertical stacking with 10px gaps

## Component Library

### Header
- **Background**: Linear gradient `90deg, #4B2E83 to #6b3fb5`
- **Height**: 18px padding top/bottom
- **Logo**: 52x36px rounded rectangle, orange gradient background, purple "FDX" text
- **Navigation**: Right-aligned links, white text, 600 weight, 16px left margin spacing

### Cards
- **Background**: White
- **Border Radius**: 10-12px (softer, modern feel)
- **Shadow**: `0 6px 18px rgba(20,20,30,0.06)` (subtle, elevated)
- **Padding**: 16-28px depending on content importance

### Buttons
- **Primary**: Purple background, white text, 700 weight
- **Secondary**: Orange background, white text
- **Padding**: 10-14px vertical/horizontal
- **Border Radius**: 8px
- **No borders**, cursor pointer

### Form Inputs
- **Border**: 1px solid `#e6e6ef` (very light)
- **Border Radius**: 8px
- **Padding**: 10-12px
- **Full width** by default

### Hero Section
- **Background**: Subtle gradient `90deg, rgba(75,46,131,0.06) to rgba(255,122,0,0.03)`
- **Layout**: Flexbox with left content area and right tracking widget (320px fixed)
- **Padding**: 28px
- **Border Radius**: 12px
- **Responsive**: Stack vertically on mobile

## Page-Specific Patterns

### Homepage
- Hero with dual CTAs ("Get a Quote" primary, "Track Shipment" secondary)
- Inline tracking widget (card-within-hero pattern)
- 3-column feature grid below hero
- Features: Express Shipping, API Integrations, Security & Support

### Login/Register
- **Centered card** layout, max-width 520px
- Vertical form stacking with 10px gaps
- Single primary CTA button
- Inline error/success messaging

### Dashboard
- **Shipment list** with card-based rows
- Status badges with color coding
- "Create New Shipment" prominent button
- Logout functionality in header

### Tracking Page
- **Public-facing** search interface
- Timeline/event display for tracking history
- Status visualization with location markers

## Interactive Elements
- **Minimal animations**: Avoid distracting motion
- **Message displays**: Toggle visibility with 5-second auto-hide
- **Color-coded feedback**: Green for success, crimson for errors
- **Loading states**: Simple text indicators ("Fetching...")

## Images
**No hero images required**. This is a utility-focused logistics platform prioritizing:
- Clean data display
- Fast form interactions
- Dashboard efficiency
- Logo/branding as primary visual element

The geometric gradient backgrounds and bold purple-orange color scheme provide sufficient visual interest without imagery.

## Accessibility
- High contrast text (dark on light)
- Clear focus states for forms
- Semantic HTML structure
- Responsive mobile layouts